import "./styles.css";
const inputFirst = document.getElementById("first");
const inputSecond = document.getElementById("second");
const inputThird = document.getElementById("third");
const inputFourth = document.getElementById("fourth");
const btn = document.querySelector("button");
const totalpara = document.getElementById("total");
const promediopara = document.getElementById("promedio");

let first: number = 0;
let second: number = 0;
let third: number = 0;
let fourth: number = 0;

btn.addEventListener("click", () => {
  first = Number(inputFirst.value);
  second = Number(inputSecond.value);
  third = Number(inputThird.value);
  fourth = Number(inputFourth.value);

  let total: number = first + second + third + fourth;
  let prom: number = total / 4;

  console.log("Tiempo total: " + total + "\nTiempo promedio: " + prom);
  totalpara?.innerHTML = "Tiempo total: " + total;
  promediopara?.innerHTML = "Tiempo Promedio: " + prom;
});
